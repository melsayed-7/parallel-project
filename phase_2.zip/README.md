
## Phase 1

```bash
git clone https://github.com/moustafa-7/parallel-project.git
```


``` bash
cd parallel-project/phase_1
```

``` bash
chmod +x commands.sh
```

``` bash
./commands.sh
```

## Phase 2

```bash
git clone https://github.com/moustafa-7/parallel-project.git
```


``` bash
cd parallel-project/
```

``` bash
run the whole jupyter notebook (inside Colab, please skip the mounting of the drive cell)
```


